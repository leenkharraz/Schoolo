---
name: Warm Educational Excellence
colors:
  surface: '#fff8f5'
  surface-dim: '#e8d7cc'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1e9'
  surface-container: '#fcebe0'
  surface-container-high: '#f6e5da'
  surface-container-highest: '#f0dfd5'
  on-surface: '#221a14'
  on-surface-variant: '#544337'
  inverse-surface: '#382e27'
  inverse-on-surface: '#ffede3'
  outline: '#877365'
  outline-variant: '#dac2b1'
  surface-tint: '#914d00'
  primary: '#914d00'
  on-primary: '#ffffff'
  primary-container: '#ea8b33'
  on-primary-container: '#592d00'
  inverse-primary: '#ffb77e'
  secondary: '#476179'
  on-secondary: '#ffffff'
  secondary-container: '#c8e3ff'
  on-secondary-container: '#4b657e'
  tertiary: '#30647d'
  on-tertiary: '#ffffff'
  tertiary-container: '#77a9c4'
  on-tertiary-container: '#003e54'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcc3'
  primary-fixed-dim: '#ffb77e'
  on-primary-fixed: '#2f1500'
  on-primary-fixed-variant: '#6e3900'
  secondary-fixed: '#cde5ff'
  secondary-fixed-dim: '#afc9e5'
  on-secondary-fixed: '#001d32'
  on-secondary-fixed-variant: '#2f4960'
  tertiary-fixed: '#c1e8ff'
  tertiary-fixed-dim: '#9bcdea'
  on-tertiary-fixed: '#001e2b'
  on-tertiary-fixed-variant: '#114c64'
  background: '#fff8f5'
  on-background: '#221a14'
  surface-variant: '#f0dfd5'
typography:
  h1:
    fontFamily: Lexend
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Lexend
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Lexend
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Lexend
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Lexend
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Lexend
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.01em
  caption:
    fontFamily: Lexend
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-margin: 24px
  gutter: 16px
  card-padding: 20px
  stack-gap: 12px
---

## Brand & Style

This design system is built to foster a sense of academic ambition rooted in cultural warmth. It targets Saudi students, educators, and parents, prioritizing a "Professional-Friendly" spectrum. The emotional response should be one of "approachable authority"—where the app feels as reliable as a prestigious institution but as welcoming as a personal tutor.

The design style follows a **Modern Corporate** approach with a **Tactile Card-based** layout. It avoids the coldness of typical enterprise software by using a sun-drenched palette and soft geometric shapes. High-quality imagery should feature local Saudi educational environments, showcasing modern architecture, diverse learning settings, and authentic student interactions to ground the digital experience in reality.

## Colors

The palette is inspired by the Saudi landscape and modern academic branding. 
- **Primary (#EA8B33):** Used for key actions and progress indicators, providing energy and optimism.
- **Background (#FEF6E7):** A warm, paper-like off-white that reduces eye strain during long study sessions.
- **Deep Navy (#132F45):** Provides the professional anchor, used for primary typography and headers to establish trust.
- **Ocean Blue (#32667F):** Acts as a calming secondary color for informational components and secondary actions.
- **Accents:** The golds and yellows are reserved for highlights, badges, and celebratory moments (like completing a lesson).

## Typography

**Lexend** is utilized across all levels of the design system. Its design specifically reduces visual stress, making it the ideal choice for an educational context where reading comprehension is paramount.

- **Headlines:** Use Bold weights for H1 and Semibold for H2/H3 in the Deep Navy (#132F45) color to ensure strong hierarchy.
- **Body Text:** Use Regular weight with a generous line height (1.6) to improve legibility on mobile devices.
- **RTL Support:** Ensure the Arabic equivalent (such as IBM Plex Sans Arabic or a complementary Lexend-style Arabic face) maintains the same x-height and optical weight to preserve the brand's friendly character across languages.

## Layout & Spacing

The layout utilizes a **Fixed Grid** for tablet/desktop and a fluid **12-column system** for mobile, with 24px side margins to give the content room to breathe. 

A consistent 8px spatial scale governs all padding and margins. Vertical rhythm is established through "stacking" cards with 16px gaps. Large sections of content should be separated by 40px or more to maintain a clean, uncluttered appearance that aids focus. Elements are grouped within cards to create distinct mental models for different subjects or tasks.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Ambient Shadows**. 

1. **Base:** The background is the warmest #FEF6E7.
2. **Cards:** White (#FFFFFF) surfaces sit on top of the background with a very soft, diffused shadow (10% opacity of the Deep Navy color) to create a subtle lift.
3. **Interactive Elements:** Buttons and active states use a slightly more pronounced shadow to invite interaction.
4. **Modals:** High-elevation overlays use a 20% backdrop blur to maintain context while focusing the user's attention.

Avoid harsh black shadows; instead, use tinted shadows derived from the #132F45 palette to keep the interface feeling natural and integrated.

## Shapes

The shape language is defined by **Smooth, Rounded Corners**. 
- Standard components (Buttons, Inputs) use a 0.5rem (8px) radius.
- Container elements (Cards, Image wrappers) use a 1rem (16px) radius to create a soft, friendly silhouette.
- Large featured components or "hero" cards can scale up to 1.5rem (24px).

This medium-large roundedness communicates accessibility and modern design, moving away from the "sharp" feel of legacy academic software.

## Components

- **Cards:** The primary container. White background, 16px rounded corners, subtle navy-tinted shadow. Use for lessons, course previews, and progress snapshots.
- **Buttons:** Primary buttons use the #EA8B33 background with white text and 8px rounded corners. Secondary buttons use the Ocean Blue (#32667F) as an outline or low-opacity fill.
- **Input Fields:** Use a light border (#E5DCCB) and a white fill. Upon focus, the border transitions to the Primary Orange with a subtle glow. Labels should always be visible above the field.
- **Chips:** Used for subject tags (e.g., "Mathematics," "History"). Use low-saturation versions of the accent colors with 24px (pill) rounding.
- **Progress Bars:** High-contrast #EA8B33 trackers against a #E5DCCB background to clearly show student advancement.
- **Navigation:** A clean bottom navigation bar on mobile with icons in Deep Navy, utilizing the Primary Orange for the active state indicator.
- **Educational Widgets:** Custom components like "Quiz Options" should have large hit areas and provide tactile feedback through slight scale-down animations when pressed.